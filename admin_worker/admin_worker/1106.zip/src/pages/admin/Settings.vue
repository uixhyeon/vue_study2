<template>
<div class="space-y-6 bg-white text-black dark:bg-black dark:text-white p-4 rounded">
설정


</div>


</template>
<script setup></script>