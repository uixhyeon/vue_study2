<template>
<div>
정산내역
</div>
</template>
<script setup></script>