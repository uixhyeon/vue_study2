<template>
<div class="space-y-6 bg-white text-black dark:bg-black dark:text-white p-4 rounded">

    고객관리


</div>


</template>
<script setup></script>